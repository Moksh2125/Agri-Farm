import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Leaf, User, Mail, Lock, Loader } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';


const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [individualType, setIndividualType] = useState('');
  const [location, setLocation] = useState('');
  const [idProof, setIdProof] = useState(null);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const { register, error } = useAuth();
  const navigate = useNavigate();

  const validatePassword = () => {
    if (password !== confirmPassword) {
      setPasswordError('Passwords do not match');
      return false;
    }
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters long');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validatePassword() || !agreeTerms) return;

    setIsLoading(true);

    // const formData = new FormData();
    // formData.append('username', name);
    // formData.append('email', email);
    // formData.append('password', password);
    // formData.append('individual_type', individualType);
    // formData.append('location', location);
    // formData.append('id_proof', idProof);

    // const formData = {
    //   name, email, password, individualType, idProof, location
    // }

    try {
      const formData = new FormData();
      formData.append('username', name);
      formData.append('email', email);
      formData.append('password', password);
      formData.append('individual_type', individualType);
      formData.append('id_proof', idProof);
      formData.append('location', location);

      const response = await axios.post('http://127.0.0.1:8000/api/register/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      console.log('Registration successful:', response.data);
      navigate('/dashboard');
    } catch (err) {
      console.error('Registration error: ', err.response?.data || err.message);
    } finally {
      setIsLoading(false);
    }

  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg">
        <div className="text-center">
          <Leaf className="h-12 w-12 text-green-600 mx-auto" />
          <h2 className="mt-6 text-3xl font-bold text-gray-900 dark:text-white">Create an account</h2>
          <p className="text-gray-600 dark:text-gray-300">Join AgriFarm to access resources</p>
        </div>

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          {error && <div className="text-red-500 text-sm">{error}</div>}

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} required
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} onBlur={validatePassword} required
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Confirm Password</label>
            <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} onBlur={validatePassword} required
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm" />
            {passwordError && <p className="text-sm text-red-500 mt-1">{passwordError}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Individual Type</label>
            <select value={individualType} onChange={(e) => setIndividualType(e.target.value)} required
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
              <option value="">Select type</option>
              <option value="Farmer">Farmer</option>
              <option value="Government">Government</option>
              <option value="Bank">Bank</option>
              <option value="Corporate">Corporate</option>
              <option value="Event">Event</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Location</label>
            <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} required
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload ID Proof</label>
            <input type="file" onChange={(e) => setIdProof(e.target.files[0])} required
              className="mt-1 block w-full text-sm text-gray-900 bg-white rounded-md border border-gray-300 cursor-pointer" />
          </div>

          <div className="flex items-center">
            <input type="checkbox" checked={agreeTerms} onChange={(e) => setAgreeTerms(e.target.checked)}
              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded" />
            <label className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
              I agree to the Terms and Privacy Policy
            </label>
          </div>

          <button type="submit" disabled={isLoading || !agreeTerms}
            className="w-full py-2 px-4 bg-green-600 hover:bg-green-700 text-white rounded-md transition disabled:bg-green-400">
            {isLoading ? <Loader className="animate-spin h-5 w-5 mx-auto" /> : 'Create Account'}
          </button>

          <p className="text-center text-sm text-gray-600 dark:text-gray-300">
            Already have an account?{' '}
            <Link to="/login" className="text-green-600 hover:text-green-500">Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Register;
