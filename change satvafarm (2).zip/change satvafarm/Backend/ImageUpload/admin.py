from django.contrib import admin
from .models import PlantHealthReport

admin.site.register(PlantHealthReport)
