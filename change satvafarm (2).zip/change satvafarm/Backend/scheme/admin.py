from django.contrib import admin
from .models import Scheme

admin.site.register(Scheme)

# Register your models here.
